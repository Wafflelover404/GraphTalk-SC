<?php
// Heading
$_['heading_title']         = 'Product Data Export';

// Text
$_['text_export']           = 'Export Products';
